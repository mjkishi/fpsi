package wop.objectStructure;

import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentSkipListMap;

import wcc.common.RequestId;
import wop.transaction.AbstractObject;
import wop.transaction.RWInfo;


public class SiteHistory {
	private ConcurrentSkipListMap<Integer, AbstractObject> Sitehistory ;
	private ConcurrentSkipListMap<Integer, RWInfo> rwHistoryRO ;
	
	public SiteHistory(AbstractObject obj, int numNodes) {
		Integer timeStamp = new Integer(0);
		Sitehistory= new ConcurrentSkipListMap<Integer, AbstractObject>();
		Sitehistory.put(timeStamp, obj);
		rwHistoryRO=new ConcurrentSkipListMap<Integer, RWInfo>();
		rwHistoryRO.put(timeStamp, new RWInfo());	
	}
	
	
	
	public void addSitehistory(RequestId reqId, String objId,AbstractObject obj, int sn, int exeId, String line ) {
	    Sitehistory.put((Integer)sn, obj);
				//System.out.println("SiteHistory is updated by requestID "+reqId+" for account "+objId+" with seqNo "+sn+" in position "+exeId+" and object value is "+((Account)obj).getAmount()+" And object version is "+obj.getVersion()+" in line "+line);
				//synchronized(rwHistoryRO) {
				rwHistoryRO.put((Integer)sn,  new RWInfo());	
				//}			
	}
	
	public void addMainRWInfo(RequestId reqId, String objId,int sn, int exeId, String place ) {
		if(rwHistoryRO.get(sn)==null) {
		//	System.out.println("RequestId "+reqId+" with seqNo "+sn+" TRY to add itself to rwRO Queue of object "+objId+" with sn "+sn+" but it does not exist" );
		}	
		//synchronized(rwHistoryRO.get(sn)) {
		if(rwHistoryRO.get(sn).mainReqs.add(reqId)) {
		//System.out.println("RequestId "+reqId+" with seqNo "+sn+" is added to rwRO Queue of object "+objId+" with sn "+sn+" in place "+place+ " in siteId "+exeId );
			
		}
		///MA		else{
		///MA			System.out.println("RequestId "+reqId+" with seqNo "+sn+" COULD NOT BE added to rwRO Queue of object "
		///MA		+objId+" with sn!!!!! "+sn +" in place "+place);
		///MA			System.exit(-1);
		///MA	}		
  ///MA  	rwHistoryRO.get(sn).depReqs.put(reqId, new HashSet<RequestId> ());		
	//	System.out.println("RWInfo is updated by requestID "+reqId+" for account "+objId+" with seqNo "+sn+" in siteId "+exeId);		
		//}
	/*	synchronized(rwHistoryRO.get(sn)) {		
			for (Iterator<RequestId> iterator = rwHistoryRO.get(sn).mainReqs.iterator(); iterator.hasNext();) {
				RequestId oldReqId = iterator.next();    
			    if(oldReqId.getClientId()==reqId.getClientId() && oldReqId.getSeqNumber()<reqId.getSeqNumber()) {
			    	 iterator.remove();
					//	System.out.println(" ReqID: "+oldReqId+" is removed from the queue of objId "+objId+" with seqNo "+sn+" by requestId "+reqId);
		//		this.remove_num.incrementAndGet();
			    }
			}	
		}*/
	}
	
	
	public Set<RequestId> getMainRWInfo(String objId, int sn){
		while(rwHistoryRO.get(sn)==null) {}
		//synchronized(rwHistoryRO.get(sn)) {
		return rwHistoryRO.get(sn).mainReqs;
		//}
	}
	
	public boolean addToMainRWINfor(String objId, int sn, RequestId reqId) {
		//synchronized(rwHistoryRO.get(sn)) {
			/*for (Iterator<RequestId> iterator = rwHistoryRO.get(sn).mainReqs.iterator(); iterator.hasNext();) {
				RequestId oldReqId = iterator.next();    
			    if(oldReqId.getClientId()==reqId.getClientId() && oldReqId.getSeqNumber()<reqId.getSeqNumber()) {
			    	 iterator.remove();
					//	System.out.println(" ReqID: "+oldReqId+" is removed from the queue of objId "+objId+" with seqNo "+sn+" by requestId "+reqId);
					//	this.remove_num.incrementAndGet();
			    }
			}*/
			//return rwHistoryRO.get(sn).mainReqs.add(reqId);
		if(rwHistoryRO.get(sn).mainReqs.add(reqId)) {
			//System.out.println("RequestId "+reqId+" with seqNo "+sn+" is added to rwRO Queue of object "+objId+" with sn "+sn );
            return true;
		}
		else {
			return false;
		}
			//}
	}
	
	
	public Entry<Integer, AbstractObject> getLatestObject(int view) {
		Entry<Integer, AbstractObject> entry = Sitehistory.floorEntry((Integer)view);
		return entry;
		}
	public int getLatestPossibleSeqNo(int view) {
		//Integer i = Sitehistory.ceilingKey((Integer) view+1);
		//return i.intValue();
		Entry<Integer, AbstractObject> entry = Sitehistory.floorEntry((Integer)view);
		return entry.getKey().intValue();
		}
	
	public AbstractObject getLatestObject() {
		 Entry<Integer, AbstractObject> entry = Sitehistory.lastEntry();
		 return entry.getValue();		
	}
	
	public int getLatestSeqNo(	) {
		int key=Sitehistory.lastKey();	
		return key;
	}
	
}
