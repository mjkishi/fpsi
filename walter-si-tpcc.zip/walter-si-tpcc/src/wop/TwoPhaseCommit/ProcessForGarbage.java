package wop.TwoPhaseCommit;

import java.io.IOException;
import java.util.BitSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

import wcc.Version;
import wcc.Wcc;
import wcc.common.RequestId;
import wop.messages.Message;
import wop.messages.MessageType;
import wop.messages.Read;
import wop.messages.ReadAns;
import wop.messages.Remove;
import wop.network.MessageHandler;
import wop.network.Network;
import wop.network.TcpNetwork;
import wop.transaction.TransactionContext;

public class ProcessForGarbage {
	
	PriorityBlockingQueue<RequestId> garbageSentReadsQ = new PriorityBlockingQueue<RequestId>();
	PriorityBlockingQueue<RequestId> garbageReceivedReadsQ=new PriorityBlockingQueue<RequestId>();
	private TcpNetwork asyncNetwork;
	public int numNodes;
	public int numObjects;
	public Wcc wccInstance;
	private static ExecutorService ReadRequestDispatcher;
	String ACCOUNT_PREFIX = "account_";
	
	
	

	public ProcessForGarbage(Wcc wccInstance, int localId, int numNodes, int numObjects) throws IOException {
		this.wccInstance = wccInstance;
		this.numNodes = numNodes;
		this.numObjects=numObjects;
		this.asyncNetwork=new TcpNetwork(2);
		
	}
	
	public void startProcessforGarbageCollector() throws IOException {
		MessageHandler handler = new MessageHandlerImpl();
		Network.addMessageListener(MessageType.Remove, handler);
		ReadRequestDispatcher = Executors.newFixedThreadPool(40);
		asyncNetwork.start();


	}
	
	
	
	public void AddTogarbageSentReadsQ(RequestId reqId) {
		synchronized(this.garbageSentReadsQ) {
			garbageSentReadsQ.offer(reqId);
		}
	}

	public void removeFromgarbageSentReadsQ(RequestId reqId) {
		synchronized(this.garbageSentReadsQ) {
			garbageSentReadsQ.remove(reqId);
		}
	}
	
	public PriorityBlockingQueue<RequestId> getGarbageSentReadsQ(){
		synchronized(this.garbageSentReadsQ) {
		return this.garbageSentReadsQ;
		}
	}
	
	public void AddToGarbageReceivedReadsQ(RequestId reqId) {
		synchronized(this.garbageReceivedReadsQ) {
			garbageReceivedReadsQ.offer(reqId);
		}
	}

	public void removeFroGgarbageReceivedReadsQ(RequestId reqId) {
		synchronized(this.garbageReceivedReadsQ) {
			garbageReceivedReadsQ.remove(reqId);
		}
	}
	
	public PriorityBlockingQueue<RequestId> getGarbageReceivedReadsQ(){
		synchronized(this.garbageReceivedReadsQ) {
		return this.garbageReceivedReadsQ;
		}
	}
	
	
    public void onRemove(Remove msg, int sender){
    	for (int i = 0; i < this.numObjects; i++) {
			String objectId = ACCOUNT_PREFIX + Integer.toString(i);
			if(wccInstance.IfReplicate(objectId)) {
				Version v=wccInstance.getStore().getStore().get(objectId).lastversion;
				if(wccInstance.getStore().getStore().get(objectId).getSitehistory(v.getlocalId()).getMainRWInfo(objectId, v.getSeqNo()).remove(msg.getRequestId())) {
				//System.out.println("REMOVE");
				}
			}
			
		}
		
	}
	
   /*public void sendRemove(RequestId reqId){
    	Remove remove=new Remove(reqId);
    	this.asyncNetwork.sendToAll(remove);
		
	}*/
	
	 private class MessageHandlerImpl implements MessageHandler {
		public void onMessageReceived(Message msg, int sender) {
			MessageEvent event = new MessageEvent(msg, sender);
	    	 ReadRequestDispatcher.execute(event);
		}

		public void onMessageSent(Message message, BitSet destinations) {
			// Empty
		}
	}
	
	
	
	
	
	/* c */ private class MessageEvent implements Runnable {
		private final Message msg;
		private final int sender;

		public MessageEvent(Message msg, int sender) {
			this.msg = msg;
			this.sender = sender;
		}

		public void run() {
			try {
				switch (msg.getType()) {
				case Remove:
					 Remove remove = (Remove) msg;
					//System.out.println("Remove is received for "+msg.getRequestId()+" from sender "+sender+" for object "+remove.getObjectId());
					 onRemove(remove,sender);
					break;
				
				default:
					logger.warning("Unknown message type: " + msg);
				}
			} catch (Throwable t) {
				logger.log(Level.SEVERE, "Unexpected exception", t);
				System.out.println("The type of exception whichh happened here in Read is for requestId "
						+ msg.getRequestId() + " from sender " + sender);
				t.printStackTrace();
				System.out.println(msg.getType());
				System.exit(1);
			}
		}
	}
	
	
	private final static Logger logger = Logger.getLogger(ProcessinRead.class.getCanonicalName());

	
}
