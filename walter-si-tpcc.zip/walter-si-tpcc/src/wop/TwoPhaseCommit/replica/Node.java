package wop.TwoPhaseCommit.replica;

import java.io.IOException;

import wcc.Wcc;
import wcc.common.Configuration;
import wcc.common.ProcessDescriptor;
import wop.TwoPhaseCommit.ProcessForGarbage;
import wop.TwoPhaseCommit.ProcessinRead;
import wop.TwoPhaseCommit.Processintwopc;
import wop.service.STMService;




public class Node {
	Processintwopc processintwopc;
	ProcessinRead processinread;
	//ProcessForGarbage processForGarbage;


	public Node(Configuration config,STMService service, int localId, Wcc wccInstance, int numNodes, long Timeout) throws IOException {
		ProcessDescriptor.initialize(config, localId);
		processintwopc=new Processintwopc(wccInstance,localId);
		processinread=new ProcessinRead(wccInstance,localId,numNodes);
		//processForGarbage=new ProcessForGarbage(wccInstance,localId,numNodes,numObjects);
		
	}

	public void start() throws IOException {
		processintwopc.startTwopcforProcess();
		processinread.startProcessforRead(/*processintwopc.getNetwork()*/);
		//processForGarbage.startProcessforGarbageCollector();
	}


	public Processintwopc getProcessintwopc(){
		return processintwopc;
	}

	public ProcessinRead getProcessinRead(){
		return processinread;
	}
	
	/*public ProcessForGarbage getProcessForGarbage(){
		return processForGarbage;
	}*/

	public Wcc getWcc(){
		return  processintwopc.getWccInstance();
	}

}