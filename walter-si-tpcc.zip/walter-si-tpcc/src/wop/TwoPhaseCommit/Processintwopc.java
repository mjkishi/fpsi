package wop.TwoPhaseCommit;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.BitSet;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicIntegerArray;
import java.util.logging.Level;
import java.util.logging.Logger;

import wcc.Wcc;
import wcc.common.RequestId;
import wop.TwoPhaseCommit.Processintwopc.NodeStatusUpdator;
import wop.messages.Abort;
import wop.messages.Commit;
import wop.messages.Message;
import wop.messages.MessageType;
import wop.messages.Prepare;
import wop.messages.PrepareAns;
import wop.messages.Propagate;
import wop.network.MessageHandler;
import wop.network.Network;
import wop.network.TcpNetwork;
import wop.transaction.AbstractObject;
import wop.transaction.TransactionContext;

public class Processintwopc {
	private final TcpNetwork network;
	private Wcc wccInstance;
	int localId;
	private ConcurrentHashMap<RequestId, TwopcSample> TwopcMap;
	public int numNodes;
	private static ExecutorService RequestDispatcher;
	PriorityBlockingQueue<PendingCommit> PropagateQ = new PriorityBlockingQueue<PendingCommit>();
	//public static int final_time=0;
	NodeStatusUpdator  nodeStatusHandler;
	ConcurrentLinkedQueue<PendingCommit> propagationList;

	public Processintwopc(Wcc wccInstance, int localId) throws IOException {
		this.wccInstance = wccInstance;
		this.network = new TcpNetwork(0);
		this.localId = localId;
		TwopcMap = new ConcurrentHashMap<RequestId, TwopcSample>();
		this.numNodes = wccInstance.getNumNodes();
		RequestDispatcher = Executors.newFixedThreadPool(20);
		propagationList=new ConcurrentLinkedQueue<PendingCommit> ();
	}

	public void startTwopcforProcess() {
		// System.out.println("Start process for 2pc");
		MessageHandler handler = new MessageHandlerImpl();
		Network.addMessageListener(MessageType.Prepare, handler);
		Network.addMessageListener(MessageType.PrepareAns, handler);
		Network.addMessageListener(MessageType.Commit, handler);
		Network.addMessageListener(MessageType.Abort, handler);
		Network.addMessageListener(MessageType.Propagate, handler);
		network.start();
		nodeStatusHandler=new NodeStatusUpdator(this);
		this.nodeStatusHandler.start();
		

	}

	public void removeTwopcSample(RequestId requestId) {
		if (TwopcMap.containsKey(requestId)) {
			TwopcMap.remove(requestId);
			//BF	System.out.println("REQID " + requestId + " is removedddddddddddddddddddd");
		}
	}

	public Wcc getWccInstance() {
		return this.wccInstance;
	}

	public void Prepare(RequestId requestId) throws IOException, InterruptedException {
		TransactionContext ctx = wccInstance.getlocalTransactionContext(requestId);
		BitSet finalDestination = new BitSet();
		TwopcSample twopcOK = new TwopcSample();
		byte[] vts = wccInstance.serializeVC(ctx.getStartVC());
		Iterator<String> iterator = ctx.getWriteSet().keySet().iterator();
		while (iterator.hasNext()) {
			String Id = (String) iterator.next();
			BitSet Destination = wccInstance.getDestination(Id);
			for (int i = 0; i < numNodes; i++) {
				if (Destination.get(i)) {
					finalDestination.set(i);
				}
			}

		}
		twopcOK.SetDestination(finalDestination);
		TwopcMap.put(requestId, twopcOK);
		int probablesn = (wccInstance.getNodeStatus().getNodeStatus()[localId]);
		byte[] writeSet=wccInstance.getSTMService().serializeWriteSet(ctx);
		Prepare msg = new Prepare(requestId, probablesn, ctx.getWriteSet().size(), ctx.getWriteSetByteSize(),
				writeSet, vts, this.numNodes);
		int recivers = 0;
		for (int i = finalDestination.nextSetBit(0); i >= 0; i = finalDestination.nextSetBit(i + 1)) {
			// System.out.println("ReqId "+msg.getRequestId()+" sends prepare to "+i+" And
			// OK count is "+twopcOK.getOKcount());
			network.sendMessage(msg, i);
			recivers = recivers + 1;
			while (twopcOK.getReceivedcount() != recivers) {
				// Thread.sleep(1);
			}
			if (ctx.getReady()) {
				break;
			}
		}

	}

	// onPrepare
	public /*synchronized*/ void onPrepare(Prepare prepare, int sender) throws IOException {
		boolean ok = true;
		int[] startVTS = wccInstance.deserializeVC(prepare.getStartVC());
		/*
		 * for(int i=0; i<numNodes;i++) { System.out.println("For reqIDD"
		 * +prepare.getRequestId()+"startVTS in position "+i+" is "+startVTS[i]); }
		 */
		Map<String, AbstractObject> writeset = wccInstance.getSTMService().deserializeWriteSet(prepare.getwsize(),
				prepare.getwriteSet());
		ok = wccInstance.IsUpdateOK(prepare.getRequestId(), startVTS, writeset, sender, " IS UPDATEOK on prepare");
		Set<RequestId> collection;
		//System.out.println("Collected set for RequestId "+prepare.getRequestId()+" has size "+collection.size());
		
		/*	for(RequestId r: collection) {
			System.out.println("RequestId in OnPrepare "+r+" exists in collectionSet of requestId "+prepare.getRequestId());		
		}*/
		
		if (!ok) {
			byte[] collectionByte=new byte[prepare.getRequestId().byteSize()];
			collectionByte=prepare.getRequestId().toByteArray();
			SendPrepareNOK(prepare, sender, collectionByte.length,collectionByte);
		} else {
			collection=wccInstance.collectAntiDep(prepare.getRequestId(), startVTS, writeset, sender);
			//wccInstance.getSTMService().addToCollectedNum(collection.size());
			byte[] collectionByte=this.serializeCollectionSet(prepare.getRequestId(), collection);
			SendPrepareOK(prepare, sender, collectionByte.length,collectionByte );
		}
	}

	public byte[] serializeCollectionSet(RequestId reqId,Set<RequestId> collection) throws IOException {	
		ByteBuffer bb;
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		for (RequestId requestId : collection) {
			if (requestId!=null) {
				bb=ByteBuffer.allocate(requestId.byteSize());
				bb.put(requestId.toByteArray());
				bb.flip();
				out.write(bb.array());
			}
			else {
				System.out.println("Error");
				System.exit(-1);
			}
		}
		return out.toByteArray();
	}

	public Set<RequestId> deserializeCollectionSet(RequestId reqId ,byte[] collectionByte , int sizeOfCollectionByte){
		ByteBuffer bb = ByteBuffer.wrap(collectionByte);
		Set<RequestId> collectionSet=new HashSet<RequestId>(sizeOfCollectionByte);
		for (int i = 0; i < sizeOfCollectionByte/reqId.byteSize(); i++) {
			RequestId requestId=new RequestId (bb.getLong(), bb.getInt());
			if( collectionSet.add(requestId)) {
			}
		}
		return collectionSet;
	}


	public void SendPrepareOK(Prepare msg, int sender, int collectionByteSize, byte[]  collectionByte) { 
		PrepareAns m = new PrepareAns(msg, 0,collectionByteSize, collectionByte);
		network.sendMessage(m, sender);
	}

	public void SendPrepareNOK(Prepare msg, int sender, int collectionByteSize, byte[]  collectionByte) { // onPrepare ----CORRECT
		PrepareAns m = new PrepareAns(msg, 1,collectionByteSize, collectionByte);
		network.sendMessage(m, sender);
	}

	public /*synchronized*/ void onPrepareAns(PrepareAns msg, int sender) throws IOException, InterruptedException {
		if (msg.getSuccess() == 0) {
			TwopcSample twopcOK = TwopcMap.get(msg.getRequestId());
			twopcOK.addToCollectedSet(deserializeCollectionSet(msg.getRequestId(), msg.getCollectedRW(), msg.getSizeOfCollectedRW()), msg.getRequestId());
			twopcOK.addToVotedIds(sender);
			twopcOK.incrementOKcount();
			twopcOK.incrementReceivedcount();
			TwopcMap.put(msg.getRequestId(), twopcOK);
			// System.out.println("For reqId "+msg.getRequestId()+"DEst NUm is
			// "+twopcOK.getDestNum()+" and OK count is "+twopcOK.getOKcount());
			if (twopcOK.getOKcount() == twopcOK.getDestNum() /*&& TwopcMap.get(msg.getRequestId()).setFinish()*/) {
				//BF System.out.println("ReqId " + msg.getRequestId() + " is before the send Commit");
				twopcOK.incrementOKcount();
				wccInstance.getSTMService().IncreaseCommitCount();
				BitSet PropagationDest=SendCommit((PrepareAns) msg);
				//BF System.out.println("ReqId " + msg.getRequestId() + " is after the send Commit");
				wccInstance.getSTMService().addToCollectedNum(twopcOK.getCollectedSet().size());
				
				wccInstance.getlocalTransactionContext(msg.getRequestId()).setReady("SEND COMMIT Line 340", msg.getRequestId());
				//Print ThreadID
				//System.out.println("\t\t\t Thread I: PREPARE "+Thread.currentThread());
				
				//public PendingCommit(RequestId reqId,Map<String, AbstractObject>WriteSet, int sn, int updator, int[] commitVC, Set<RequestId> collectedSet){
				//PendingCommit(RequestId reqId, int sn, int[] startVC)
				PendingCommit pc=new PendingCommit(msg.getRequestId(),wccInstance.getlocalTransactionContext(msg.getRequestId()).getSeqNo(), 
						wccInstance.getlocalTransactionContext(msg.getRequestId()).getStartVCArray(),PropagationDest);
				
				propagationList.add(pc);
				
				
				
				while(!wccInstance.getlocalTransactionContext(msg.getRequestId()).getReadyToRemove()) {}
				wccInstance.removeTransactionContext(msg.getRequestId());
				wccInstance.getSTMService().getNode().getProcessinRead().removeReadReq(msg.getRequestId());
				wccInstance.getSTMService().getNode().getProcessintwopc().removeTwopcSample(msg.getRequestId());
			}
		} else {
			onPrepareNOK(msg, sender);
		}
	}

	public /*synchronized*/ void onPrepareNOK(PrepareAns msg, int sender) throws IOException {
		RequestId requestId = msg.getRequestId();
		TransactionContext ctx = wccInstance.getlocalTransactionContext(requestId);
		if (TwopcMap.get(msg.getRequestId()).getVotedIds().size() != 0) {
			//BF System.out.println("ReqId " + msg.getRequestId() + " is in the IF part of Send Abort");
			byte[] wset = wccInstance.getSTMService().serializeWriteSet(ctx);
			int wsize = ctx.getWriteSet().size();
			Abort a = new Abort(msg, wsize, wset);
			boolean nextIf=true;
			for (Integer id : TwopcMap.get(msg.getRequestId()).getVotedIds()) {
				//BF	System.out.println("ReqId " + msg.getRequestId() + " sends abort to " + id);
				if(TwopcMap.get(msg.getRequestId()) !=null && TwopcMap.get(msg.getRequestId()).getVotedIds().contains(this.localId)) {
					nextIf=false;
				}
				network.sendMessage(a, id);
			}

			if (nextIf && TwopcMap.get(msg.getRequestId()) != null
					&& !TwopcMap.get(msg.getRequestId()).getVotedIds().contains(this.localId)) {
				//BF	System.out.println("ReqId " + msg.getRequestId() + " is in the LIne 195");
				ctx.setRetry();
				ctx.setReady("onPrepareNOK Line 195", msg.getRequestId());
				TwopcMap.get(msg.getRequestId()).incrementReceivedcount();
			}

		} else {
			//BF	System.out.println("ReqId " + msg.getRequestId() + " is in the ELSE part of Send Abort");
			ctx.setRetry();
			ctx.setReady("onPrepareNOK Line 208", msg.getRequestId());
			TwopcMap.get(msg.getRequestId()).incrementReceivedcount();
		}
	}

	// onCommit
	public void onCommit(Commit msg, int sender) throws InterruptedException { // onCommit ---CORRECT
		//System.out.println("Commit is received for requestId  "+msg.getRequestId()+" from "+sender);
		int wsize = msg.getwsize();
		byte[] wset = msg.getwriteSet();
		Map<String, AbstractObject> WriteSet = wccInstance.getSTMService().deserializeWriteSet(wsize, wset);
		int sn = msg.getSeqNo();
		int[] commitVTS=wccInstance.deserializeVC(msg.getCommitVTS());
		//BF	System.out.println("For reqId " + msg.getRequestId() + " from sender " + sender + " sn is " + sn
		//BF		+ " and writesetsize is" + wsize);
		Set<RequestId> collectedSet=this.deserializeCollectionSet(msg.getRequestId(), msg.getCollectedRW(), msg.getSizeOfCollectedRW());
		//for(RequestId r:collectedSet) {
		//	System.out.println("RequestID"+ r+" exists in collectedset of "+msg.getRequestId());
		//}
		wccInstance.FinishCommit(msg.getRequestId(), WriteSet, sn, sender, "Finish Commit onCommit",commitVTS,collectedSet);

	}

	// onAbort
	public void onAbort(Abort msg, int sender) throws IOException {
		int wsize = msg.getwsize();
		byte[] wset = msg.getwriteSet();
		Map<String, AbstractObject> WriteSet = wccInstance.getSTMService().deserializeWriteSet(wsize, wset);
		for (Map.Entry<String, AbstractObject> entry : WriteSet.entrySet()) {
			String Id = entry.getKey();
			if (wccInstance.getStore().Ifreplicate(Id)) {
				wccInstance.ReleaseLock(Id, sender, msg.getRequestId(), "Line 247 on Abort");
			}
		}

		if (sender == this.localId) {
			TransactionContext ctx = wccInstance.getlocalTransactionContext(msg.getRequestId());
			ctx.setRetry();
			ctx.setReady("In ON ABORT Line 234", msg.getRequestId());
			TwopcMap.get(msg.getRequestId()).incrementReceivedcount();
		}
	}


	public synchronized BitSet SendCommit(PrepareAns msg) throws IOException, InterruptedException {
		int[] commitVC=new int[this.numNodes];
		RequestId requestId = msg.getRequestId();
		TransactionContext ctx = wccInstance.getlocalTransactionContext(requestId);
		BitSet PropagationDest = new BitSet();
		Set<RequestId> collectedSet= TwopcMap.get(msg.getRequestId()).getCollectedSet();
		//for(RequestId rId: collectedSet) {
		//		System.out.println("BEFORE SENDING COMMIT requestId "+rId+" exists in the collectedSet which is gotten from TwopcMap od requestId "+msg.getRequestId());
		//}
		int sn = wccInstance.incrementSeqNo(msg.getRequestId());
		if(ctx!=null) {
			

			ctx.SetSeqNo(sn);
			for (Map.Entry<String, AbstractObject> entry : ctx.getWriteSet().entrySet()) {
				AbstractObject obj = entry.getValue();
				String Id = entry.getKey();
				if (wccInstance.getStore().Ifreplicate(Id)) {
					wccInstance.getStore().updateStore(requestId, this.localId, Id, sn, obj/*,ctx.getStartVCArray()*/," line 361");
					for(RequestId r: collectedSet) {
						int siteId= wccInstance.getStore().getLastVersion(Id).getlocalId();
						int sNumber= wccInstance.getStore().getLastVersion(Id).getSeqNo();
							if(wccInstance.getStore().getStore().get(Id).getSitehistory(siteId).addToMainRWINfor(Id, sNumber, r)){
							//System.out.println("RequestId "+r+" with seqNo "+sNumber+" is added to rwRO Queue of object "
							//+Id+" with sn "+sNumber+" in place "+" sendCommit 1" );
								//wccInstance.getStore().getStore().get(Id).numOfAntiDepREquests.incrementAndGet();
							//wccInstance.getStore().addToVersionBound(Id, r, sNumber, siteId, this.numNodes);
						}
					}
				}
			}
			if (wccInstance.getNodeStatus().getNodeStatus()[this.localId] == sn - 1) {
				//BFSystem.out.println("RequestId " + msg.getRequestId() + " commits itself and sn is" + sn
				//BF		+ " and nodeStatus " + wccInstance.getNodeStatus().getNodeStatus()[this.localId]);
				//int[] commitVC= new int[this.numNodes];	
				commitVC=wccInstance.getNodeStatus().UpdateNodeStatus(msg.getRequestId(), sn, this.localId,"Line 346");
				for (String Id : ctx.getWriteSet().keySet()) {
					if (wccInstance.getStore().Ifreplicate(Id)) {
						wccInstance.getStore().getLastVersion(Id).getObject().setVC(commitVC);
								/*for(int i=0; i<this.numNodes;i++) {
									System.out.println(" RequestId "+requestId+ " for objId "+Id+" with ver# "+
											wccInstance.getStore().getLastVersion(Id).getObject().getVersion() +": inserted new vc at position "+i+
										" is "+wccInstance.getStore().getLastVersion(Id).getObject().vc[i]+" in line 404");
								}*/
						wccInstance.ReleaseLock(Id, this.localId, msg.getRequestId(), "Line 304 Send Commit");
					}
				}
				sn = sn + 1;
				synchronized (wccInstance.getPendingCommits((Integer) this.localId)) {
					PendingCommit QHead = wccInstance.getPendingCommits(this.localId).getPendQ().peek();
					while (QHead != null && QHead.getSeqNo() == sn) {
						//BFSystem.out.println("ReqId " + msg.getRequestId() + " finds reqId " + QHead.getRequestId()
						//BF	+ " which has seq No" + QHead.getSeqNo() + " and is helping to commit it");
						if(QHead.getWriteSet()!=null) {
							for (String Id : QHead.getWriteSet().keySet()) {
								if (wccInstance.getStore().Ifreplicate(Id)) {
									wccInstance.getStore().updateStore(QHead.getRequestId(), QHead.getUpdator(), Id, QHead.getSeqNo(), 
											QHead.getWriteSet().get(Id)/*,ctx.getStartVCArray()*/, " line 423");
									//////////////////////////added on July 11
									for(RequestId r: QHead.getCollectedSet()) {
										int siteId= wccInstance.getStore().getLastVersion(Id).getlocalId();
										int sNumber= wccInstance.getStore().getLastVersion(Id).getSeqNo();
											if(wccInstance.getStore().getStore().get(Id).getSitehistory(siteId).addToMainRWINfor(Id, sNumber, r)){
											//System.out.println("RequestId "+r+" with seqNo "+sNumber+" is added to rwRO Queue of object "
												//	+Id+" with sn "+sNumber+" in place "+" sendCommit 2" );
											//		wccInstance.getStore().getStore().get(Id).numOfAntiDepREquests.incrementAndGet();
										//wccInstance.getStore().addToVersionBound(Id, r, sNumber, siteId, this.numNodes);
										   }
									}
								}
							}
						}
						wccInstance.getNodeStatus().UpdateNodeStatus(QHead.getRequestId(), QHead.getSeqNo(),
								QHead.getUpdator(), "LINE 371");
						for (String Id : QHead.getWriteSet().keySet()) {
							if (wccInstance.getStore().Ifreplicate(Id)) {
								wccInstance.ReleaseLock(Id, QHead.getUpdator(), QHead.getRequestId(),
										"Line 314 Send Commit");
							}

						}
						//PendingCommit l=wccInstance.getPendingCommits((Integer) this.localId).getPendQ().poll();
						//BFSystem.out.println(" reqId "+msg.getRequestId()+" removes "+l.getSeqNo());
						sn = sn + 1;
						QHead = wccInstance.getPendingCommits((Integer) localId).getPendQ().peek();
					}
				}
			} else {
				synchronized (wccInstance.getPendingCommits((Integer) this.localId)) {
					int[] commitVC1= wccInstance.getNodeStatus().getNodeStatus();
					commitVC1[this.localId]=sn;
					wccInstance.getPendingCommits((Integer) this.localId)
					.AddToPendQ(new PendingCommit(msg.getRequestId(), ctx.getWriteSet(), sn, this.localId, commitVC1, collectedSet));
					//BF System.out.println(" ReqId " + msg.getRequestId() + " shuld be added to the pendingCommits in line 380 ");
				}
			}
			byte[] writeSet = wccInstance.getSTMService().serializeWriteSet(ctx);
			byte[] commitVTSByte= wccInstance.serializeVC(commitVC);
			// System.out.println("before creating commit is reachable");
			byte[] collectedSetByte=this.serializeCollectionSet(msg.getRequestId(), TwopcMap.get(msg.getRequestId()).getCollectedSet());
			//Commit c = new Commit(msg, ctx.getWriteSet().size(), writeSet, this.numNodes, commitVTSByte, ctx.getSeqNo(), collectedSetByte.length,collectedSetByte );
			
			//Commit(PrepareAns msg, int wsize,int wsizeByte,byte[] writeSet,int numNodes,byte[] commitVTS, int sn, int sizeOfCollectedRW, byte[] collectedRW)
			
			Commit c = new Commit(msg, ctx.getWriteSet().size(),writeSet.length ,writeSet, this.numNodes, commitVTSByte, ctx.getSeqNo(), collectedSetByte.length,collectedSetByte);

			// System.out.println("Inside commit message seqNo is"+c.getSeqNo() +"for
			// requestId "+ requestId+"from sender "+PId);
			//	System.out.println("For reqId "+msg.getRequestId()+" conflicting vc in position is "+ctx.getStartVC());
			for (int k = 0; k < this.numNodes; k++) {
				PropagationDest.set(k);
			}
			PropagationDest.andNot(TwopcMap.get(msg.getRequestId()).getDestinations());
			PropagationDest.clear(this.localId);
			/////M		System.out.println("Propagation Dest for reqId " + msg.getRequestId() + " is " + PropagationDest);
			TwopcMap.get(msg.getRequestId()).getDestinations().clear(this.localId);
			if (TwopcMap.get(msg.getRequestId()).getDestinations().cardinality() != 0) {
				network.sendMessage(c, TwopcMap.get(msg.getRequestId()).getDestinations());
			}
			/////M	System.out.println("Commit message can be sent/finished for requestId " + requestId + "to destinations"
			/////M		+ TwopcMap.get(msg.getRequestId()).getDestinations());
			
		}
		return PropagationDest;

	}

   



	public /*synchronized*/ void onPropagate(Propagate msg, int sender) throws InterruptedException {
		//BFSystem.out.println(" RequesId " + msg.getRequestId() + " from sender " + sender + " called propagate");
		//10=6 & 20=22
		//Thread.sleep(0, 1);
		/*int time=0;
		for(int i=0;i<3000000; i++) {
			time=time+1;
		}
		final_time=time;*/
		synchronized (wccInstance.getPendingCommits((Integer) sender)) {
			/***Commit lesser seqNo which are trapped in the Queue**/
			PendingCommit QHead = wccInstance.getPendingCommits().get((Integer) sender).getPendQ().peek();
			int committing = msg.getSeqNo() - 1;
			if(wccInstance.getNodeStatus().getNodeStatus()[sender]==committing-1) {
				if (QHead != null && QHead.getSeqNo() == committing) {
					if(QHead.getWriteSet()!=null) {
						for (String Id : QHead.getWriteSet().keySet()) {
							if (wccInstance.getStore().Ifreplicate(Id)) {
								wccInstance.getStore().updateStore(QHead.getRequestId(), QHead.getUpdator(), Id, QHead.getSeqNo(), 
										QHead.getWriteSet().get(Id)/*,startVTS*/, "line 534 ");
							}
						}
					}
					wccInstance.getNodeStatus().UpdateNodeStatus(QHead.getRequestId(), QHead.getSeqNo(), QHead.getUpdator()," line 449");
					//Delay UPDATE NODE STATUS
					/*if(QHead.getWriteSet()!=null) {
						wccInstance.getNodeStatus().UpdateNodeStatus(QHead.getRequestId(), QHead.getSeqNo(), QHead.getUpdator()," line 449");
					}
					
					else {
						//Thread.sleep(10);
						//wccInstance.getNodeStatus().UpdateNodeStatus(QHead.getRequestId(), QHead.getSeqNo(), QHead.getUpdator()," line 45");
						this.nodeStatusHandler.wccInstance.getNodeStatus().UpdateNodeStatus(QHead.getRequestId(), QHead.getSeqNo(), QHead.getUpdator()," h");

					}*/
					
					if (QHead.getWriteSet() != null) {
						for (String Id : QHead.getWriteSet().keySet()) {
							if (wccInstance.getStore().Ifreplicate(Id)) {
								wccInstance.ReleaseLock(Id, QHead.getUpdator(), QHead.getRequestId(),
										"Libe 323 Finish Commit");
							}

						}
					}
					//PendingCommit l=wccInstance.getPendingCommits().get((Integer) sender).getPendQ().poll();
					//BFSystem.out.println(" reqId "+msg.getRequestId()+" removes "+l.getSeqNo());
					//committing=committing-1;
					//QHead = wccInstance.getPendingCommits().get((Integer) sender).getPendQ().peek();
				}

			}
			/***End of Commit lesser seqNo which are trapped in the Queue**/
			
			/***Start of the commit the seqNo which is received by propagate**/
			if (wccInstance.getNodeStatus().getNodeStatus()[sender] == (msg.getSeqNo() - 1)) {
				wccInstance.deserializeVC(msg.getStartVC());	
				wccInstance.getNodeStatus().UpdateNodeStatus(msg.getRequestId(), msg.getSeqNo(), sender, " line 477");
				//DO NOT UPDATE NODE STATUS
				//this.nodeStatusHandler.wccInstance.getNodeStatus().UpdateNodeStatus(msg.getRequestId(), msg.getSeqNo(), sender, " h");
				/***End of the commit the seqNo which is received by propagate**/	
				/***Start of the commit the seqNo which is bigger than the reqNo**/
				QHead = wccInstance.getPendingCommits().get((Integer) sender).getPendQ().peek();
				int sn = msg.getSeqNo();
				sn = sn + 1;
				while (QHead != null && QHead.getSeqNo() == sn) {
					if(QHead!=wccInstance.getPendingCommits().get((Integer) sender).getPendQ().peek()) {
						break;
					}
					//BFSystem.out.println("ReqId " + msg.getRequestId() + " finds reqId " + QHead.getRequestId()
					//BF		+ " which has seq No" + QHead.getSeqNo() + " and is helping to commit it in Line 477");
					if(QHead.getWriteSet()!=null) {
						for (String Id : QHead.getWriteSet().keySet()) {
							if (wccInstance.getStore().Ifreplicate(Id)) {
								wccInstance.getStore().updateStore(QHead.getRequestId(), QHead.getUpdator(),
										Id, QHead.getSeqNo(), QHead.getWriteSet().get(Id)/*,startVTS1*/," line 595");
								for(RequestId r: QHead.getCollectedSet()) {
									int siteId= wccInstance.getStore().getLastVersion(Id).getlocalId();
									int sNumber= wccInstance.getStore().getLastVersion(Id).getSeqNo();
										if(wccInstance.getStore().getStore().get(Id).getSitehistory(siteId).addToMainRWINfor(Id, sNumber, r)) {
											//System.out.println("RequestId "+r+" with seqNo "+sNumber+" is added to rwRO Queue of object "
											//		+Id+" with sn "+sNumber+" in place "+" sendCommit 2" );
											
										//			wccInstance.getStore().getStore().get(Id).numOfAntiDepREquests.incrementAndGet();
										//wccInstance.getStore().addToVersionBound(Id, r, sNumber, siteId, this.numNodes);
									    }
								}

							}
						}
					}
					wccInstance.getNodeStatus().UpdateNodeStatus(QHead.getRequestId(), QHead.getSeqNo(),
							QHead.getUpdator(), " line 504");
					
					//DO NOT UPDATE NODE STATUS
					/*if(QHead.getWriteSet()!=null) {
					wccInstance.getNodeStatus().UpdateNodeStatus(QHead.getRequestId(), QHead.getSeqNo(),
							QHead.getUpdator(), " line 504");
					}
					else {
						//Thread.sleep(10);
						//wccInstance.getNodeStatus().UpdateNodeStatus(QHead.getRequestId(), QHead.getSeqNo(),
						//		QHead.getUpdator(), " line 504");
						this.nodeStatusHandler.wccInstance.getNodeStatus().UpdateNodeStatus(QHead.getRequestId(), QHead.getSeqNo(),
										QHead.getUpdator(), " h");
					}*/
					
					if (QHead.getWriteSet() != null) {
						for (String Id : QHead.getWriteSet().keySet()) {
							if (wccInstance.getStore().Ifreplicate(Id)) {
								wccInstance.getStore().getLastVersion(Id).getObject().setVC(QHead.getCommitVC());
								wccInstance.ReleaseLock(Id, QHead.getUpdator(), QHead.getRequestId(),
										"Libe 323 Finish Commit");
							}
						}
					}
					PendingCommit l=wccInstance.getPendingCommits().get((Integer) sender).getPendQ().poll();
					//BF System.out.println(" reqId "+msg.getRequestId()+" removes "+l.getSeqNo());
					sn = sn + 1;
					QHead = wccInstance.getPendingCommits().get((Integer) sender).getPendQ().peek();
				}
			}

			else {
				wccInstance.getPendingCommits((Integer)sender).AddToPendQ(new PendingCommit(msg.getRequestId(), msg.getSeqNo(), sender));
				//BF System.out.println(" ReqId " + msg.getRequestId() + " shuld be added to the pendingCommits in line 509 ");
			}
		}
	}

	
	/***********************************/
	/**
	 * Receives messages from other processes and stores them on the pendingEvents
	 * queue for processing by the Dispatcher thread.
	 */
	private class MessageHandlerImpl implements MessageHandler {

		public void onMessageReceived(Message msg, int sender) {
			MessageEvent event = new MessageEvent(msg, sender);
			RequestDispatcher.execute(event);
		}
		public void onMessageSent(Message message, BitSet destinations) {
			// Empty
		}

	}

	private class MessageEvent implements Runnable {
		private final Message msg;
		private final int sender;

		public MessageEvent(Message msg, int sender) {
			this.msg = msg;
			this.sender = sender;
		}

		public void run() {
			try {

				switch (msg.getType()) {
				case Prepare:
					//BF	System.out.println("Recieved PREPARE for requestId " + msg.getRequestId() + "from " + sender);
					onPrepare((Prepare) msg, sender);
					break;
				case PrepareAns:
					//BF	System.out.println("Recieved PREPAREAns for requestId " + msg.getRequestId() + "from " + sender);
					onPrepareAns((PrepareAns) msg, sender);
					break;
				case Commit:
					//BF	System.out.println("Recieved Commit for requestId " + msg.getRequestId() + "from " + sender);
					onCommit((Commit) msg, sender);
					break;
				case Abort:
					//BF	System.out.println("Recieved Abort for requestId " + msg.getRequestId() + "from " + sender);
					onAbort((Abort) msg, sender);
					break;
				case Propagate:
					//BF	System.out.println("Recieved Propagate for requestId " + msg.getRequestId() + "from " + sender);
					onPropagate((Propagate) msg, sender);
					break;
				default:
					logger.warning("Unknown message type: " + msg);
				}
			} catch (Throwable t) {
				logger.log(Level.SEVERE, "Unexpected exception", t);
				t.printStackTrace();
				System.out.println(
						"The type of exception whichh happened here in twopc is " + t.getMessage() + " from sender "
								+ sender + " for msg type " + msg.getType() + " and requestId " + msg.getRequestId());
				System.exit(-1);
			}
		}
	}
	
	class NodeStatusUpdator extends Thread {
		//Wcc wccInstance;
		Processintwopc p;
		NodeStatusUpdator(/*Wcc wccInstance*/Processintwopc p){
			//this.wccInstance=wccInstance;
			this.p=p;
			
		}
		
	 public void sendPropagartion(RequestId requestId, int[] startVC,BitSet PropagationDest, int seqNo) throws InterruptedException {
		    	//Print ThreadID
			 //System.out.println("\t\t\t Thread ID: AFTER PREPARE "+Thread.currentThread());
			 	Thread.sleep(1);
		    	if (PropagationDest.cardinality() != 0) {
					byte[] sendVC = wccInstance.serializeVC(startVC);
					Propagate p = new Propagate(requestId, sendVC, seqNo,numNodes);
					network.sendMessage(p, PropagationDest);
				}
		    }
		
	
		

		public void run() {
			while(true) {
				try {
					
					while(propagationList.size()==0) {}
					PendingCommit pc=propagationList.poll();
					sendPropagartion(pc.getRequestId(), pc.getCommitVC(),pc.getPropagationDestination(), pc.getSeqNo());
					
					
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				//System.out.println("heyyyyy heyyyy heyyy\t\t\t Thread FUCK:C "+Thread.currentThread());
			}
			
			//Thread.sleep(30000);
		}
	}
	

	private final static Logger logger = Logger.getLogger(Processintwopc.class.getCanonicalName());

}