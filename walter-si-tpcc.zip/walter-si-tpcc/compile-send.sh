ant build
ant jar
scp ppaxos.jar root@cr130.cse.lehigh.edu:/root/sss-proxy/exec
